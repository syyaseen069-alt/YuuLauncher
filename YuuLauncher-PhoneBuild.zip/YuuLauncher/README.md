# Yuu Launcher

A free, open-source starter project for a Niagara-inspired Android launcher.

## Current prototype features
- Android HOME/default-launcher intent filters
- Installed app discovery and launch
- Vertical app list and A-Z jump strip
- Search
- Long-press favorites persisted locally
- Dark/light theme toggle
- Basic horizontal swipe gesture (left focuses search, right clears it)
- Usage statistics ordering using Android's Usage Access settings
- Notification listener service skeleton and notification-access settings shortcut
- Android AppWidgetHost picker flow (basic prototype)

## Important limitations
This is a starter prototype, not a production-ready Niagara clone. Widget IDs/views are not yet restored after process death or reboot; widget configuration and OEM-specific behavior require device testing. Notification support currently counts active notifications and does not yet render notification cards. Icon-pack support, advanced animations, app shortcuts, robust gesture customization, backup/export, and accessibility polish remain future work.

The app does not request Internet access and does not upload your app list, favorites, usage information, or notifications.

## Build
Open this folder as a Gradle Android project in Android Studio or a compatible Android build environment. Use JDK 17 with Android Gradle Plugin 8.7.3, Gradle 8.9, and Android SDK platform 35. Then build the `app` module and install the generated APK.

If building on a phone, ensure the IDE supports this Android Gradle Plugin and SDK level. On-device build environments may need additional setup and may not support every modern Gradle version.

## Package
`com.yuu.minilauncher`

## License
MIT. See `LICENSE`.

## Build from an Android phone using GitHub Actions

1. Create a GitHub account and a **public** repository named `YuuLauncher`.
2. Upload the contents of this project folder to the repository root (not the enclosing `YuuLauncher` folder).
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. The workflow runs on pushes to `main`; you can also choose **Build Yuu Launcher APK** → **Run workflow**.
5. Open the completed workflow run, scroll to **Artifacts**, and download `YuuLauncher-debug-apk`.
6. Extract the artifact ZIP and install `app-debug.apk`. Android may ask you to allow installs from your browser or file manager.

GitHub-hosted standard runners are free for public repositories. The repository will be public, so its source code will be visible to others. Do not upload passwords, signing keys, or personal information.

This workflow uses Gradle 8.9 and Java 17, and is intended to build the debug APK. It has not been executed from this chat, so a build error may still need fixing.
