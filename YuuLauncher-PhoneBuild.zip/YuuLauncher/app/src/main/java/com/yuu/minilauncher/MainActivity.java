package com.yuu.minilauncher;

import android.app.Activity;
import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetHostView;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.appwidget.AppWidgetHost;
import android.appwidget.AppWidgetManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;

public class MainActivity extends Activity {
    private static final int REQUEST_CREATE_WIDGET = 4101;
    private static final int REQUEST_BIND_WIDGET = 4102;
    private static final int HOST_ID = 7241;

    private int backgroundColor = Color.rgb(18, 18, 22);
    private int foregroundColor = Color.rgb(245, 245, 248);
    private int mutedColor = Color.rgb(160, 160, 175);
    private int accentColor = Color.rgb(255, 190, 100);

    private LinearLayout root;
    private LinearLayout appList;
    private LinearLayout widgetContainer;
    private ScrollView appScroll;
    private EditText search;
    private TextView favoritesHeading;
    private boolean darkTheme = true;
    private boolean showUsageOrder = false;

    private final List<AppEntry> allApps = new ArrayList<>();
    private final Set<String> favorites = new HashSet<>();
    private SharedPreferences prefs;
    private AppWidgetManager widgetManager;
    private AppWidgetHost widgetHost;

    static class AppEntry {
        String name;
        String packageName;
        String className;
        Drawable icon;

        AppEntry(String n, String p, String c, Drawable i) {
            name = n;
            packageName = p;
            className = c;
            icon = i;
        }
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("launcher_settings", MODE_PRIVATE);
        favorites.addAll(prefs.getStringSet("favorites", new HashSet<String>()));
        darkTheme = prefs.getBoolean("dark_theme", true);
        showUsageOrder = prefs.getBoolean("usage_order", false);

        widgetManager = AppWidgetManager.getInstance(this);
        widgetHost = new AppWidgetHost(this, HOST_ID);
        buildScreen();
        loadApps();
        renderApps("");
        renderWidgets();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (prefs != null && appList != null) {
            loadApps();
            renderApps(search == null ? "" : search.getText().toString());
            updateStatusLine();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (widgetHost != null) widgetHost.startListening();
    }

    @Override
    protected void onStop() {
        if (widgetHost != null) {
            try { widgetHost.stopListening(); } catch (Exception ignored) {}
        }
        super.onStop();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void updateColors() {
        if (darkTheme) {
            backgroundColor = Color.rgb(18, 18, 22);
            foregroundColor = Color.rgb(245, 245, 248);
            mutedColor = Color.rgb(160, 160, 175);
        } else {
            backgroundColor = Color.rgb(247, 246, 242);
            foregroundColor = Color.rgb(32, 32, 38);
            mutedColor = Color.rgb(105, 105, 115);
        }
    }

    private TextView makeText(String value, float size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private Button makeButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setAllCaps(false);
        return b;
    }

    private void buildScreen() {
        updateColors();
        getWindow().setStatusBarColor(backgroundColor);
        getWindow().setNavigationBarColor(backgroundColor);
        getWindow().getDecorView().setSystemUiVisibility(0);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(10), dp(8));
        root.setBackgroundColor(backgroundColor);
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(top, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        top.addView(titleBox, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView title = makeText("yuu.", 32, foregroundColor);
        title.setTypeface(null, Typeface.BOLD);
        titleBox.addView(title);
        TextView subtitle = makeText("Your phone. Your space.", 13, mutedColor);
        titleBox.addView(subtitle);

        Button themeButton = makeButton(darkTheme ? "☼" : "☾");
        themeButton.setOnClickListener(v -> {
            darkTheme = !darkTheme;
            prefs.edit().putBoolean("dark_theme", darkTheme).apply();
            buildScreen();
            loadApps();
            renderApps(search == null ? "" : search.getText().toString());
            renderWidgets();
        });
        top.addView(themeButton);

        search = new EditText(this);
        search.setSingleLine(true);
        search.setTextColor(foregroundColor);
        search.setHintTextColor(mutedColor);
        search.setHint("Search apps...");
        search.setTextSize(16);
        search.setPadding(dp(12), 0, dp(12), 0);
        search.setBackgroundColor(darkTheme ? Color.rgb(38, 38, 45) : Color.rgb(229, 228, 224));
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        searchParams.topMargin = dp(16);
        root.addView(search, searchParams);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(actions, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button widgetsButton = makeButton("+ Widget");
        widgetsButton.setOnClickListener(v -> pickWidget());
        actions.addView(widgetsButton);

        Button usageButton = makeButton("Usage");
        usageButton.setOnClickListener(v -> toggleUsageOrder());
        actions.addView(usageButton);

        Button notificationButton = makeButton("Notifications");
        notificationButton.setOnClickListener(v -> openNotificationSettings());
        actions.addView(notificationButton);

        TextView status = makeText("", 11, mutedColor);
        status.setTag("status_line");
        actions.addView(status, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        updateStatusLine();

        widgetContainer = new LinearLayout(this);
        widgetContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(widgetContainer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams contentParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        contentParams.topMargin = dp(4);
        root.addView(content, contentParams);

        appScroll = new ScrollView(this);
        appScroll.setFillViewport(false);
        content.addView(appScroll, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        appList = new LinearLayout(this);
        appList.setOrientation(LinearLayout.VERTICAL);
        appScroll.addView(appList);

        LinearLayout alphabet = new LinearLayout(this);
        alphabet.setOrientation(LinearLayout.VERTICAL);
        alphabet.setGravity(Gravity.CENTER);
        content.addView(alphabet, new LinearLayout.LayoutParams(dp(25),
                ViewGroup.LayoutParams.MATCH_PARENT));

        for (char c = 'A'; c <= 'Z'; c++) {
            final String letter = String.valueOf(c);
            TextView item = makeText(letter, 10, mutedColor);
            item.setGravity(Gravity.CENTER);
            alphabet.addView(item, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            item.setOnClickListener(v -> jumpTo(letter));
        }

        search.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                renderApps(s.toString());
            }
            @Override public void afterTextChanged(android.text.Editable e) {}
        });

        GestureDetector detector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                if (e1 != null && e2 != null) {
                    float dx = e2.getX() - e1.getX();
                    float dy = e2.getY() - e1.getY();
                    if (Math.abs(dx) > dp(100) && Math.abs(dx) > Math.abs(dy)) {
                        if (dx < 0) {
                            search.requestFocus();
                            search.setSelection(search.length());
                        } else {
                            search.setText("");
                            search.clearFocus();
                        }
                        return true;
                    }
                }
                return false;
            }
        });
        root.setOnTouchListener((v, event) -> detector.onTouchEvent(event));
    }

    private void updateStatusLine() {
        if (root == null) return;
        View v = root.findViewWithTag("status_line");
        if (v instanceof TextView) {
            ((TextView) v).setText("● " + LauncherNotificationListener.getActiveNotificationCount());
        }
    }

    private void loadApps() {
        allApps.clear();
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        List<ResolveInfo> results = pm.queryIntentActivities(intent, 0);
        Set<String> seen = new HashSet<>();

        for (ResolveInfo info : results) {
            String pkg = info.activityInfo.packageName;
            if (!seen.add(pkg)) continue;
            String name = info.loadLabel(pm).toString();
            String cls = info.activityInfo.name;
            Drawable icon = info.loadIcon(pm);
            allApps.add(new AppEntry(name, pkg, cls, icon));
        }
        Collections.sort(allApps, Comparator.comparing(a -> a.name.toLowerCase(Locale.ROOT)));
    }

    private void renderApps(String query) {
        if (appList == null) return;
        appList.removeAllViews();
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        List<AppEntry> shown = new ArrayList<>();
        for (AppEntry app : allApps) {
            if (app.name.toLowerCase(Locale.ROOT).contains(q)) shown.add(app);
        }

        Map<String, Long> usage = showUsageOrder ? getUsageMap() : new HashMap<String, Long>();
        Collections.sort(shown, (a, b) -> {
            boolean af = favorites.contains(a.packageName);
            boolean bf = favorites.contains(b.packageName);
            if (af != bf) return af ? -1 : 1;
            if (showUsageOrder) {
                long au = usage.containsKey(a.packageName) ? usage.get(a.packageName) : 0L;
                long bu = usage.containsKey(b.packageName) ? usage.get(b.packageName) : 0L;
                if (au != bu) return Long.compare(bu, au);
            }
            return a.name.compareToIgnoreCase(b.name);
        });

        if (shown.isEmpty()) {
            TextView empty = makeText("No apps found", 15, mutedColor);
            empty.setPadding(0, dp(20), 0, dp(20));
            appList.addView(empty);
            return;
        }

        if (q.isEmpty()) {
            TextView favTitle = makeText("FAVORITES", 10, mutedColor);
            favTitle.setTypeface(null, Typeface.BOLD);
            favTitle.setPadding(dp(4), dp(10), 0, dp(4));
            appList.addView(favTitle);
            for (AppEntry app : shown) {
                if (favorites.contains(app.packageName)) addAppRow(app);
            }
            TextView allTitle = makeText("ALL APPS", 10, mutedColor);
            allTitle.setTypeface(null, Typeface.BOLD);
            allTitle.setPadding(dp(4), dp(12), 0, dp(4));
            appList.addView(allTitle);
        }
        for (AppEntry app : shown) addAppRow(app);
    }

    private void addAppRow(AppEntry app) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), dp(6), dp(4), dp(6));
        row.setTag(app.name);

        ImageView icon = new ImageView(this);
        icon.setImageDrawable(app.icon);
        row.addView(icon, new LinearLayout.LayoutParams(dp(36), dp(36)));

        TextView label = makeText(app.name, 16, foregroundColor);
        label.setPadding(dp(12), 0, dp(4), 0);
        row.addView(label, new LinearLayout.LayoutParams(0, dp(44), 1f));

        if (favorites.contains(app.packageName)) {
            TextView star = makeText("★", 16, accentColor);
            row.addView(star);
        }

        row.setOnClickListener(v -> {
            Intent launch = getPackageManager().getLaunchIntentForPackage(app.packageName);
            if (launch != null) {
                try { startActivity(launch); }
                catch (Exception e) { Toast.makeText(this, "Couldn't open app", Toast.LENGTH_SHORT).show(); }
            }
        });
        row.setOnLongClickListener(v -> {
            if (favorites.contains(app.packageName)) favorites.remove(app.packageName);
            else favorites.add(app.packageName);
            prefs.edit().putStringSet("favorites", new HashSet<>(favorites)).apply();
            renderApps(search.getText().toString());
            return true;
        });
        appList.addView(row);
    }

    private void jumpTo(String letter) {
        if (appList == null || appScroll == null) return;
        for (int i = 0; i < appList.getChildCount(); i++) {
            View child = appList.getChildAt(i);
            Object tag = child.getTag();
            if (tag instanceof String && ((String) tag).toUpperCase(Locale.ROOT).startsWith(letter)) {
                appScroll.smoothScrollTo(0, child.getTop());
                return;
            }
        }
        Toast.makeText(this, "No apps under " + letter, Toast.LENGTH_SHORT).show();
    }

    private void toggleUsageOrder() {
        showUsageOrder = !showUsageOrder;
        prefs.edit().putBoolean("usage_order", showUsageOrder).apply();
        if (!hasUsageAccess()) {
            try { startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); }
            catch (ActivityNotFoundException ignored) {}
            Toast.makeText(this, "Allow usage access, then return here.", Toast.LENGTH_LONG).show();
        } else {
            renderApps(search.getText().toString());
        }
    }

    private boolean hasUsageAccess() {
        try {
            UsageStatsManager manager = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            List<UsageStats> stats = manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,
                    now - 7L * 24L * 60L * 60L * 1000L, now);
            return stats != null && !stats.isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    private Map<String, Long> getUsageMap() {
        Map<String, Long> result = new HashMap<>();
        if (!hasUsageAccess()) return result;
        try {
            UsageStatsManager manager = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
            long now = System.currentTimeMillis();
            List<UsageStats> stats = manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,
                    now - 7L * 24L * 60L * 60L * 1000L, now);
            if (stats != null) {
                for (UsageStats stat : stats) {
                    result.put(stat.getPackageName(), stat.getTotalTimeInForeground());
                }
            }
        } catch (Exception ignored) {}
        return result;
    }

    private void openNotificationSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Open Android notification access in Settings.", Toast.LENGTH_LONG).show();
        }
    }

    private void pickWidget() {
        int appWidgetId = widgetHost.allocateAppWidgetId();
        Intent pick = new Intent(AppWidgetManager.ACTION_APPWIDGET_PICK);
        pick.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        try {
            startActivityForResult(pick, REQUEST_CREATE_WIDGET);
        } catch (Exception e) {
            widgetHost.deleteAppWidgetId(appWidgetId);
            Toast.makeText(this, "Widget picker isn't available on this device.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CREATE_WIDGET) {
            if (resultCode == RESULT_OK && data != null) {
                int id = data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1);
                if (id >= 0) {
                    AppWidgetProviderInfo info = widgetManager.getAppWidgetInfo(id);
                    if (info != null) {
                        if (info.configure != null) {
                            Intent configure = new Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE);
                            configure.setComponent(info.configure);
                            configure.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
                            startActivityForResult(configure, REQUEST_BIND_WIDGET);
                        } else {
                            addWidgetView(id);
                        }
                    }
                }
            }
        } else if (requestCode == REQUEST_BIND_WIDGET && resultCode == RESULT_OK && data != null) {
            int id = data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1);
            if (id >= 0) addWidgetView(id);
        }
    }

    private void renderWidgets() {
        if (widgetContainer == null) return;
        widgetContainer.removeAllViews();
        TextView label = makeText("WIDGETS", 10, mutedColor);
        label.setTypeface(null, Typeface.BOLD);
        widgetContainer.addView(label);
        // Widget views are added when selected; IDs are managed by AppWidgetHost.
    }

    private void addWidgetView(int appWidgetId) {
        AppWidgetProviderInfo info = widgetManager.getAppWidgetInfo(appWidgetId);
        if (info == null) return;
        AppWidgetHostView hostView = widgetHost.createView(this, appWidgetId, info);
        hostView.setAppWidget(appWidgetId, info);
        widgetContainer.addView(hostView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }
}
