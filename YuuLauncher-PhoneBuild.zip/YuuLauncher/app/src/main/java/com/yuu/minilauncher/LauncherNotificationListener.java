package com.yuu.minilauncher;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public class LauncherNotificationListener extends NotificationListenerService {
    private static volatile int activeNotificationCount = 0;

    public static int getActiveNotificationCount() {
        return activeNotificationCount;
    }

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        refreshCount();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        refreshCount();
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        refreshCount();
    }

    private void refreshCount() {
        try {
            StatusBarNotification[] notifications = getActiveNotifications();
            activeNotificationCount = notifications == null ? 0 : notifications.length;
        } catch (Exception ignored) {
            activeNotificationCount = 0;
        }
    }
}
